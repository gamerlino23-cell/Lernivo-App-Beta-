import { NextResponse } from 'next/server';
import OpenAI from 'openai';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function POST(req: Request) {
  try {
    const { messages } = await req.json();
    const response = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: 'Du bist LERNIVO, ein KI-Lernassistent entwickelt von Lino Gipser.' },
        ...messages
      ],
    });
    return NextResponse.json({ reply: response.choices[0].message.content });
  } catch (e) {
    return NextResponse.json({ reply: 'Hallo! Ich bin LERNIVO, dein KI-Lernassistent entwickelt von Lino Gipser.' });
  }
}