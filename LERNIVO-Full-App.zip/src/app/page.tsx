import Link from 'next/link';

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-8 bg-slate-900 text-white">
      <h1 className="text-4xl font-bold mb-4">LERNIVO</h1>
      <p className="text-slate-400 mb-8">Entwickelt von Lino Gipser</p>
      <div className="flex gap-4">
        <Link href="/login" className="px-6 py-3 bg-indigo-600 rounded-xl font-semibold">Anmelden</Link>
        <Link href="/register" className="px-6 py-3 bg-slate-800 rounded-xl font-semibold">Registrieren</Link>
      </div>
    </main>
  );
}